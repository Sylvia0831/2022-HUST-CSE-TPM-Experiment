
#ifndef __TCPA_ERROR_H__
#define __TCPA_ERROR_H__

#warning including deprecated header file tcpa_error.h

#endif
